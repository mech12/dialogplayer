package com.androidbegin.menuviewpagertutorial;

import com.wecandoit.jinju_0_0_3.*;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ViewPagerAdapter_myfile extends FragmentPagerAdapter {

	// Declare the number of ViewPager pages
	private String titles[] = new String[] { 
			"Local",
			"Working", 
			"Favorite",
			"Search",
			};

	public ViewPagerAdapter_myfile(FragmentManager fm) {
		super(fm);
	}

	@Override
	public Fragment getItem(int position) {
		switch (position) {
		case 0:
			return new FragmentTab_Local();
		case 1:
			return new FragmentTab_Working();
		case 2:
			return new FragmentTab_Favorite();
		case 3:
			return new FragmentTab_Search();
		}
		return null;
	}

	public CharSequence getPageTitle(int position) {
		return titles[position];
	}

	@Override
	public int getCount() {
		return titles.length;
	}

}